package forecast;

public class Forecaster {

    // Recursive method to predict future value
    public static double predictFutureValue(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        } else {
            return predictFutureValue(initialValue, growthRate, years - 1) * (1 + growthRate);
        }
    }

    // Optimized version using memoization (optional)
    public static double predictWithMemo(double initialValue, double growthRate, int years, double[] memo) {
        if (years == 0) return initialValue;
        if (memo[years] != 0) return memo[years];

        memo[years] = predictWithMemo(initialValue, growthRate, years - 1, memo) * (1 + growthRate);
        return memo[years];
    }

    public static void main(String[] args) {
        double initialValue = 10000; // Starting value
        double growthRate = 0.08;    // 8% annual growth
        int years = 5;

        System.out.println("📈 Predicting future value using recursion:");
        double result = predictFutureValue(initialValue, growthRate, years);
        System.out.printf("After %d years, value = ₹%.2f\n", years, result);

        System.out.println("\n💡 Using memoized recursion:");
        double[] memo = new double[years + 1];
        double memoResult = predictWithMemo(initialValue, growthRate, years, memo);
        System.out.printf("After %d years (optimized), value = ₹%.2f\n", years, memoResult);
    }
}
