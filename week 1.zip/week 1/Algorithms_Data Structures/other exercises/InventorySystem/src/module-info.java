/**
 * 
 */
/**
 * 
 */
module InventorySystem {
}