package tasklist;

import java.util.Scanner;

public class TaskManager {
    static Task head = null;  // Start of the linked list

    // Add Task to End
    public static void addTask(int id, String name, String status) {
        Task newTask = new Task(id, name, status);
        if (head == null) {
            head = newTask;
        } else {
            Task temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newTask;
        }
        System.out.println("Task added!");
    }

    // Search Task by ID
    public static Task searchTask(int id) {
        Task temp = head;
        while (temp != null) {
            if (temp.taskId == id) return temp;
            temp = temp.next;
        }
        return null;
    }

    // Delete Task by ID
    public static void deleteTask(int id) {
        if (head == null) {
            System.out.println("No tasks to delete.");
            return;
        }

        if (head.taskId == id) {
            head = head.next;
            System.out.println("Task deleted!");
            return;
        }

        Task prev = head;
        Task current = head.next;

        while (current != null && current.taskId != id) {
            prev = current;
            current = current.next;
        }

        if (current != null) {
            prev.next = current.next;
            System.out.println("Task deleted!");
        } else {
            System.out.println("Task not found!");
        }
    }

    // Traverse and Display All Tasks
    public static void displayTasks() {
        if (head == null) {
            System.out.println("No tasks to display.");
            return;
        }

        System.out.println("\nTask List:");
        Task temp = head;
        while (temp != null) {
            temp.display();
            temp = temp.next;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n1. Add Task\n2. Search Task\n3. Delete Task\n4. Display Tasks\n5. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Task ID: ");
                    int id = sc.nextInt();
                    sc.nextLine(); // consume newline
                    System.out.print("Enter Task Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Status: ");
                    String status = sc.nextLine();
                    addTask(id, name, status);
                    break;

                case 2:
                    System.out.print("Enter Task ID to search: ");
                    id = sc.nextInt();
                    Task found = searchTask(id);
                    if (found != null) found.display();
                    else System.out.println("Task not found!");
                    break;

                case 3:
                    System.out.print("Enter Task ID to delete: ");
                    id = sc.nextInt();
                    deleteTask(id);
                    break;

                case 4:
                    displayTasks();
                    break;

                case 5:
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice!");
            }
        }

        sc.close();
    }
}
