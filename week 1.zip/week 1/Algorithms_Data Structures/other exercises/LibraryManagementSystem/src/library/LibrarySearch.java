package library;

import java.util.Arrays;
import java.util.Comparator;

public class LibrarySearch {

    // Linear search by title
    public static Book linearSearch(Book[] books, String targetTitle) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(targetTitle)) {
                return book;
            }
        }
        return null;
    }

    // Binary search by title (assumes sorted array)
    public static Book binarySearch(Book[] books, String targetTitle) {
        int left = 0, right = books.length - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            int cmp = targetTitle.compareToIgnoreCase(books[mid].title);
            if (cmp == 0) return books[mid];
            else if (cmp < 0) right = mid - 1;
            else left = mid + 1;
        }
        return null;
    }

    public static void main(String[] args) {
        // Sample books
        Book[] books = {
            new Book(101, "Java Programming", "James Gosling"),
            new Book(102, "Python Essentials", "Guido van Rossum"),
            new Book(103, "C++ Fundamentals", "Bjarne Stroustrup"),
            new Book(104, "Data Structures", "Robert Lafore"),
            new Book(105, "Algorithms", "Thomas Cormen")
        };

        // 🔍 Linear Search
        System.out.println("📘 Linear Search:");
        Book foundLinear = linearSearch(books, "Algorithms");
        if (foundLinear != null)
            foundLinear.display();
        else
            System.out.println("Book not found!");

        // ✅ Sort by title for binary search
        Arrays.sort(books, Comparator.comparing(b -> b.title.toLowerCase()));

        // 🔍 Binary Search
        System.out.println("\n📗 Binary Search:");
        Book foundBinary = binarySearch(books, "Algorithms");
        if (foundBinary != null)
            foundBinary.display();
        else
            System.out.println("Book not found!");
    }
}
