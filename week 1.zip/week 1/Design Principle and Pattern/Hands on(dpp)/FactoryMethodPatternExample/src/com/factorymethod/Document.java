package com.factorymethod;

public interface Document {
    void open();
}
