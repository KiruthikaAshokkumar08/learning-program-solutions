package com.dependencyinjection;

public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(int id) {
        // Simulate database fetch
        return "Customer with ID " + id + ": John Doe";
    }
}
