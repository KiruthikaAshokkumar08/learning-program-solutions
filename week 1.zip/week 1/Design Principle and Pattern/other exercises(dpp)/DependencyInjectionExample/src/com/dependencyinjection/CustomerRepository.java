package com.dependencyinjection;

public interface CustomerRepository {
    String findCustomerById(int id);
}
