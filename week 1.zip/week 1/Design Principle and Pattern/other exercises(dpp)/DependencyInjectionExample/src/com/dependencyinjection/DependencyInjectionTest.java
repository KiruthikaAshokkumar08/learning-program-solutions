package com.dependencyinjection;

public class DependencyInjectionTest {
    public static void main(String[] args) {
        // Create repository instance
        CustomerRepository repository = new CustomerRepositoryImpl();

        // Inject it into the service
        CustomerService service = new CustomerService(repository);

        // Use the service
        service.getCustomerDetails(101);
    }
}
