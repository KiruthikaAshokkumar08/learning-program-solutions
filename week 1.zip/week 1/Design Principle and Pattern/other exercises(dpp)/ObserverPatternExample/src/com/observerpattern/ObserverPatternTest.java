package com.observerpattern;

public class ObserverPatternTest {
    public static void main(String[] args) {
        StockMarket market = new StockMarket();

        Observer mobile = new MobileApp("Investor1");
        Observer web = new WebApp("Investor2");

        market.registerObserver(mobile);
        market.registerObserver(web);

        System.out.println("Setting stock price to $100.0");
        market.setStockPrice(100.0);

        System.out.println("\nSetting stock price to $120.5");
        market.setStockPrice(120.5);

        market.removeObserver(mobile);

        System.out.println("\nSetting stock price to $150.0");
        market.setStockPrice(150.0);
    }
}
