package com.mvcpattern;

public class MVCPatternTest {
    public static void main(String[] args) {
        // Create model and view
        Student student = new Student();
        student.setName("Alice");
        student.setId("S123");
        student.setGrade("A");

        StudentView view = new StudentView();
        StudentController controller = new StudentController(student, view);

        // Display initial details
        controller.updateView();

        // Update student data
        controller.setStudentName("Bob");
        controller.setStudentGrade("B+");

        // Display updated details
        controller.updateView();
    }
}
