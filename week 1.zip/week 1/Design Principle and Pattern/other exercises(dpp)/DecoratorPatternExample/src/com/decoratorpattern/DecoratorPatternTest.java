package com.decoratorpattern;

public class DecoratorPatternTest {
    public static void main(String[] args) {
        // Base notifier
        Notifier notifier = new EmailNotifier();

        // Add SMS and Slack decorators
        notifier = new SMSNotifierDecorator(notifier);
        notifier = new SlackNotifierDecorator(notifier);

        // Send a message via all channels
        notifier.send("System maintenance scheduled at 10 PM.");
    }
}
