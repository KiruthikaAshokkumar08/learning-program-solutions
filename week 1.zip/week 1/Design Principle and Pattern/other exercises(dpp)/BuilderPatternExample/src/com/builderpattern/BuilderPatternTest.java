package com.builderpattern;

public class BuilderPatternTest {
    public static void main(String[] args) {
        // Create a gaming PC
        Computer gamingPC = new Computer.Builder()
                .setCPU("Intel Core i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 4080")
                .setOperatingSystem("Windows 11")
                .build();

        // Create a budget PC
        Computer budgetPC = new Computer.Builder()
                .setCPU("Intel Core i5")
                .setRAM("8GB")
                .setStorage("512GB SSD")
                .setOperatingSystem("Windows 10")
                .build();

        // Display configurations
        gamingPC.showSpecs();
        budgetPC.showSpecs();
    }
}
