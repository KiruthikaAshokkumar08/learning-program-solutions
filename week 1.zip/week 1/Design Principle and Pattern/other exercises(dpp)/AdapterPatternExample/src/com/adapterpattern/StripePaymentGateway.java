package com.adapterpattern;

public class StripePaymentGateway {
    public void makeStripePayment(double amount) {
        System.out.println("Paid " + amount + " using Stripe.");
    }
}
