package com.adapterpattern;

public class PaypalAdapter implements PaymentProcessor {
    private PaypalPaymentGateway paypalGateway;

    // Constructor takes the adaptee (PaypalPaymentGateway)
    public PaypalAdapter(PaypalPaymentGateway paypalGateway) {
        this.paypalGateway = paypalGateway;
    }

    // Implements the method from the PaymentProcessor interface
    @Override
    public void processPayment(double amount) {
        paypalGateway.sendPaypalPayment(amount); // Adapter translates the call
    }
}
