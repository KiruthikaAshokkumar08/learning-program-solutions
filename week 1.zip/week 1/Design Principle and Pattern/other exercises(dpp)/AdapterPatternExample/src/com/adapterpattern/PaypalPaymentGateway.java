package com.adapterpattern;

public class PaypalPaymentGateway {
    public void sendPaypalPayment(double amount) {
        System.out.println("Paid " + amount + " using PayPal.");
    }
}
