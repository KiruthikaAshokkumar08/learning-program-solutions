package com.adapterpattern;

public class StripeAdapter implements PaymentProcessor {
    private StripePaymentGateway stripeGateway;

    // Constructor takes the adaptee (StripePaymentGateway)
    public StripeAdapter(StripePaymentGateway stripeGateway) {
        this.stripeGateway = stripeGateway;
    }

    // Implements the method from the PaymentProcessor interface
    @Override
    public void processPayment(double amount) {
        stripeGateway.makeStripePayment(amount); // Adapter translates the call
    }
}
