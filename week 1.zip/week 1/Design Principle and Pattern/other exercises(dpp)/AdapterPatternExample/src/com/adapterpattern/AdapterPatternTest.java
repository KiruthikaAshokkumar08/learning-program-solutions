package com.adapterpattern;

public class AdapterPatternTest {
    public static void main(String[] args) {
        // Using Stripe through adapter
        StripePaymentGateway stripe = new StripePaymentGateway();
        PaymentProcessor stripeAdapter = new StripeAdapter(stripe);
        stripeAdapter.processPayment(250.0);

        // Using PayPal through adapter
        PaypalPaymentGateway paypal = new PaypalPaymentGateway();
        PaymentProcessor paypalAdapter = new PaypalAdapter(paypal);
        paypalAdapter.processPayment(180.0);
    }
}
