package com.commandpattern;

public interface Command {
    void execute();
}
