package com.proxypattern;

public class ProxyPatternTest {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        // First time – loads from remote
        image1.display(); 
        System.out.println();

        // Second time – should use cached
        image1.display(); 
        System.out.println();

        // First time – loads from remote
        image2.display();
    }
}
